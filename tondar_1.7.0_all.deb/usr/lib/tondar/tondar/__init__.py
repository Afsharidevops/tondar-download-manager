"""Tondar Download Manager - a segmented download accelerator for Ubuntu."""

APP_NAME = "Tondar Download Manager"
APP_ID = "tondar"
VERSION = "1.7.0"
API_PORT = 9614
APP_URL = "https://github.com/Afsharidevops/tondar-download-manager"
